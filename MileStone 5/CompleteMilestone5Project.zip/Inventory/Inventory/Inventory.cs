﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory
{
    public partial class Inventory : Form
    {
        public Inventory()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Inventory_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            LoadData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            con.Open();
            bool status = false;
            if(comboBox1.SelectedIndex == 0)
            {
                status = true;
            }
            else
            {
                status = false;
            }

            var sqlQuery = "";
            if (IfInventory1Exists(con, textBox1.Text))
            {
                sqlQuery = @"UPDATE [Inventory1] SET [ProductName] = '" + textBox2.Text + "' ,[QuantityInStock] = '" + textBox3.Text + "' ,[QuantityOutOfStock] = '" + textBox4.Text + "' ,[TotalStock] = '" + textBox5.Text + "' ,[Media Type] = '" + status + "' WHERE [ProductID] = '" + textBox1.Text + "'";
            }
            else
            {
                sqlQuery = @"INSERT INTO [dbo].[Inventory1]
           ([ProductID]
           ,[ProductName]
           ,[QuantityInStock]
           ,[QuantityOutOfStock]
           ,[TotalStock]
           ,[Media Type])
     VALUES
           ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + status + "')";
            }
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
           cmd.ExecuteNonQuery();
           con.Close();

            LoadData();
        }

        private bool IfInventory1Exists(SqlConnection con, string productID)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select 1 From [Inventory1] WHERE [ProductID]='" + productID + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }
        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From [dbo].[Inventory1]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["ProductID"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["ProductName"].ToString();
                dataGridView1.Rows[n].Cells[2].Value = item["QuantityInStock"].ToString();
                dataGridView1.Rows[n].Cells[3].Value = item["QuantityOutOfStock"].ToString();
                dataGridView1.Rows[n].Cells[4].Value = item["TotalStock"].ToString();
                if ((bool)item["Media Type"])
                {
                    dataGridView1.Rows[n].Cells[5].Value = "Movies";
                }
                else
                {
                    dataGridView1.Rows[n].Cells[5].Value = "Television";
                }
            }
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            if (dataGridView1.SelectedRows[0].Cells[5].Value.ToString() == "Movies")
            {
                comboBox1.SelectedIndex = 0;
            }
            else
            {
                comboBox1.SelectedIndex = 1;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            var sqlQuery = "";
            if (IfInventory1Exists(con, textBox1.Text))
            {
                con.Open();
                sqlQuery = @"DELETE FROM [Inventory1] WHERE [ProductID] = '"+ textBox1.Text +"'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                MessageBox.Show("Record of Product does not exist.");
            }
            LoadData();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            {
                SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
                var sqlQuery = "";
                if (IfInventory1Exists(con, textBox1.Text))
                {
                    con.Open();
                    sqlQuery = @"DELETE FROM [Inventory1] WHERE [ProductID] = '" + textBox1.Text + "'";
                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Record of Product does not exist.");
                }
                LoadData();
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            Hide();
        }
    }
}
