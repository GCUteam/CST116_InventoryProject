﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory
{
    public partial class Rep : Form
    {
        public Rep()
        {
            InitializeComponent();
        }

        private void Rep_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfRepsExists(con, textBox1.Text))
            {
                sqlQuery = @"UPDATE [Reps] SET [Password] = '" + textBox2.Text + "' ,[First Name] = '" + textBox3.Text + "' ,[Last Name] = '" + textBox4.Text + "' ,[Email] = '" + textBox5.Text + "' WHERE [Username] = '" + textBox1.Text + "'";
            }
            else
            {
                sqlQuery = @"INSERT INTO [dbo].[Reps]
           ([Username]
           ,[Password]
           ,[First Name]
           ,[Last Name]
           ,[Email])
     VALUES
           ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "')";
            }
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();
            con.Close();

            LoadData();
        }

        private bool IfRepsExists(SqlConnection con, string customerID)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select 1 From [Reps] WHERE [Username]='" + textBox1.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From [Reps]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["Username"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["Password"].ToString();
                dataGridView1.Rows[n].Cells[2].Value = item["First Name"].ToString();
                dataGridView1.Rows[n].Cells[3].Value = item["Last Name"].ToString();
                dataGridView1.Rows[n].Cells[4].Value = item["Email"].ToString();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            var sqlQuery = "";
            if (IfRepsExists(con, textBox1.Text))
            {
                con.Open();
                sqlQuery = @"DELETE FROM [Reps] WHERE [Username] = '" + textBox1.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                MessageBox.Show("Record of Rep does not exist.");
            }
            LoadData();
        }

        private void Rep_Load_1(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
