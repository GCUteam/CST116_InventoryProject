﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory
{
    public partial class CustomerInterface : Form
    {
        public CustomerInterface()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CustomerInventory frm = new CustomerInventory();
            frm.Show();
            Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CustomerLogin frm = new CustomerLogin();
            frm.Show();
            Hide();
        }
    }
}
