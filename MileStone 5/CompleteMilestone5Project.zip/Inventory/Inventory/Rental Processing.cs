﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Customer_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Inventory frm = new Inventory();
            frm.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfCustomersExists(con, textBox1.Text))
            {
                sqlQuery = @"UPDATE [Customers] WHERE [CustomerID] = '" + textBox1.Text + "'";
            }

            con.Close();
            LoadData();

            MessageBox.Show("Shipment Sent", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        private bool IfCustomersExists(SqlConnection con, string customerID)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select 1 From [Customers] WHERE [CustomerID]='" + customerID + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From [Customers]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["CustomerID"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["First Name"].ToString();
                dataGridView1.Rows[n].Cells[2].Value = item["Last Name"].ToString();
                dataGridView1.Rows[n].Cells[3].Value = item["Email"].ToString();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
        }

        
    }
}
