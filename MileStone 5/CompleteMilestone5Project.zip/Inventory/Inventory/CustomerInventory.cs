﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory
{
    public partial class CustomerInventory : Form
    {
        public CustomerInventory()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rental Confirmed.");
            CustomerInterface frm = new CustomerInterface();
            frm.Show();
            Hide();
        }

        private void CustomerInventory_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private bool IfInventory1Exists(SqlConnection con, string productName)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select 1 From [Inventory1] WHERE [ProductName]='" + productName + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From [dbo].[Inventory1]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["ProductName"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["QuantityInStock"].ToString();
                if ((bool)item["Media Type"])
                {
                    dataGridView1.Rows[n].Cells[2].Value = "Movies";
                }
                else
                {
                    dataGridView1.Rows[n].Cells[2].Value = "Television";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            var sqlQuery = "";
            if (IfInventory1Exists(con, textBox2.Text))
            {
                con.Open();
                sqlQuery = @"SELECT * FROM [dbo].[Inventory1] WHERE [ProductName] = '" + textBox2.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                MessageBox.Show("Currently Unavailable.");
            }
            LoadData();
        }
    }
}
