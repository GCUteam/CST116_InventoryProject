﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Milestone3Interface
{
    public partial class Form17 : Form
    {
        public Form17()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form18 frm = new Form18();
            frm.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = "John@gmail.com";
            string password = "123";

            if (textBox1.Text == "John@gmail.com" && textBox2.Text == "123")
            {
                Form19 frm = new Form19();
                frm.Show();
                Hide();
            }
            else
            {
                MessageBox.Show("Invalid Entry");
                textBox1.Text = String.Empty;
                textBox2.Text = String.Empty;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form20 frm = new Form20();
            frm.Show();
            Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form41 frm = new Form41();
            frm.Show();
            Hide();
        }
    }
}
