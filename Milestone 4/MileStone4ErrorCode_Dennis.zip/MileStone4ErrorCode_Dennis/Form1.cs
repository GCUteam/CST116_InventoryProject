﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MileStone_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Console.WriteLine("Enter User ID:  ");
            Console.ReadLine();

            if (textBox1.Text == "Username" && textBox2.Text == "Password")

            {
                Form2form2 = new Form2();
                new Form2().Show();
            }
            else
            {

                MessageBox.Show("Invalid entry.Please try again");
            }



        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Console.WriteLine("Enter Password:  ");
            Console.ReadLine();

            if (textBox1.Text == "username" && textBox2.Text == "Password")

            {
                Form2form2 = new Form2();
                new Form2().Show();
            }
            else

                MessageBox.Show("Invalid entry.Please try again");
        }
    }

    private void button1_MouseClick(object sender, EventArgs e)
    {

    }
}
