﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Milestone3Interface
{
    public partial class Form28 : Form
    {
        public Form28()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form27 frm = new Form27();
            frm.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form19 frm = new Form19();
            frm.Show();
            Hide();
        }
    }
}
