﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Milestone3Interface
{
    public partial class Form30 : Form
    {
        public Form30()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string name = "John@gmail.com";
            string password = "123";

            if (textBox3.Text == "John@gmail.com" && textBox4.Text == "123")
            {
                Form31 frm = new Form31();
                frm.Show();
                Hide();
            }
            else
            {
                MessageBox.Show("Invalid Entry");
                textBox3.Text = String.Empty;
                textBox4.Text = String.Empty;
            }
        }
    }
}
