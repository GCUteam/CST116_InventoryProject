﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }

        private void Customer_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfCustomersExists(con, textBox1.Text))
            {
                sqlQuery = @"UPDATE [Customers] SET [First Name] = '" + textBox2.Text + "' ,[Last Name] = '" + textBox3.Text + "' ,[Email] = '" + textBox4.Text + "' ,[Address] = '" + textBox5.Text + "' ,[City] = '" + textBox6.Text + "',[State] = '" + textBox7.Text + "',[Zip Code] = '" + textBox8.Text + "',[Password] = '" + textBox9.Text + "' WHERE [CustomerID] = '" + textBox1.Text + "'";
            }
            else
            {
                sqlQuery = @"INSERT INTO [dbo].[Customers]
           ([CustomerID]
           ,[First Name]
           ,[Last Name]
           ,[Email]
           ,[Address]
           ,[City]
           ,[State]
           ,[Zip Code]
           ,[Password])
     VALUES
           ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "')";
            }
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();
            con.Close();

            LoadData();
        }

        private bool IfCustomersExists(SqlConnection con, string customerID)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select 1 From [Customers] WHERE [CustomerID]='" + customerID + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From [Customers]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["CustomerID"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["First Name"].ToString();
                dataGridView1.Rows[n].Cells[2].Value = item["Last Name"].ToString();
                dataGridView1.Rows[n].Cells[3].Value = item["Email"].ToString();
                dataGridView1.Rows[n].Cells[4].Value = item["Address"].ToString();
                dataGridView1.Rows[n].Cells[5].Value = item["City"].ToString();
                dataGridView1.Rows[n].Cells[6].Value = item["State"].ToString();
                dataGridView1.Rows[n].Cells[7].Value = item["Zip Code"].ToString();
                dataGridView1.Rows[n].Cells[8].Value = item["Password"].ToString();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            textBox6.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            textBox7.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            textBox8.Text = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
            textBox9.Text = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Inventory;Integrated Security=True");
            var sqlQuery = "";
            if (IfCustomersExists(con, textBox1.Text))
            {
                con.Open();
                sqlQuery = @"DELETE FROM [Customers] WHERE [CustomerID] = '" + textBox1.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                MessageBox.Show("Record of Product does not exist.");
            }
            LoadData();
        }
    }
}
